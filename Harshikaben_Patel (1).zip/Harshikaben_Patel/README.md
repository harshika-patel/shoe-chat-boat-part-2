# <a href="https://github.com/tonazih/Week4" target="_blank">ES6 Order Bot</a>

I got the user interface for the web from Pat Wilken.

To run:

1. Sign up for paypal developer sandbox and get a client id
2. The first time run `npm install`
3. `SB_CLIENT_ID=ATpuPxGC1zvYcZpd2pO4DUT5szt2s3376syuW6zcpaASp8-v4yEpiayosLxGka5rZE0x6rZ6rgbbzd0M npm start`

## Assignment 2

Extend the order bot from assignment 1. You need to have at least 2 type of shoes . The types need to have size and one other attribute like Colour. You also need an up-sell item like Cleaner in the example.

For Assignment 2 you need to add paypal and a payment screen as in the scaffold.

### Marking

basic order for an item with payment in a zip (25%)
firstName_lastName.zip (10%)
Project directory without nesting = firstName_lastName (10%)
2 types of shoes = (up to 10%)
Upsell beside cleaner = (up to 10%)
calculation of amount (up to 10%)
error handling, for every input (up to 10%)
get the delivery address from paypal's shipping address (up to 15%)

There is a brief [presentation here](ES6Templates.pdf).